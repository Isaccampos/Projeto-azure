# Projeto-Devops
Projeto de criação dos sites para LMS 12/09
1. Ivan Sandro Cardoso Filho 1801215 - 2ºB SI
2. Song Shik Restrepo Vasconcellos Lins 1800589 - 2°B SI
3. Rafael Cordeiro Diniz 1800640 - 2ºB ADS 
4. Isac Moreira Campos 1800451 - 2ºB ADS
5. Samuel Soares da Silva 1801144 - 2ºB ADS 

  
  
